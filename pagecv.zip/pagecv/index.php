<?php
require 'header.php';
?>
<h2>Section</h2>

<div class="sidenav">
    <a href="#">Expériences</a>
    <?php
require 'experiences.php';
?>
    <a href="#">Formations</a>
    <a href="#">Langues</a>
    <a href="#">Compétences informatique</a>
</div>

<?php
require 'footer.php';
?>